﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebSite
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnIngresar_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text.ToString() == "admin" && txtClave.Text.ToString() == "admin")
            {
                Page.Response.Write("Ingreso ok");
            }
            else {
                Page.Response.Write("Error en el usuario o contraseña");
            }

        }

        protected void lnkRecordarClave_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Default.aspx?msg=Usuario descuidado");

        }
    }
}