﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Clases;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            A A = new A();
            A B = new B();
            A.M1();
            A.M2();
            A.M3();
            A.MostrarNombre();
            B.M1();
            B.M2();
            B.M3();
            B.MostrarNombre();

            System.Console.ReadLine();
        }
    }
}
