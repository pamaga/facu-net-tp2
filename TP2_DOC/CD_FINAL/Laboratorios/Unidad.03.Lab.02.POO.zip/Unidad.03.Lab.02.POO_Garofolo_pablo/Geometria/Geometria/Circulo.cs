﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Geometria
{
    public class Circulo
    {
        private int m_radio;

        public int Radio
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public void CalcularPerimetro()
        {
            throw new System.NotImplementedException();
        }

        public void CalcularSuperfie()
        {
            throw new System.NotImplementedException();
        }
    }
}
