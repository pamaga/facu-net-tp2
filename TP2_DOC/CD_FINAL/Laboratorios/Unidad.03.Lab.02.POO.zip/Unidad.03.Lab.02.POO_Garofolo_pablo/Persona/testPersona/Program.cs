﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MisClases;

namespace testPersona
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona p = new Persona("Pablo", "Apellido", "10/10/1981");
            System.Console.WriteLine("Edad: "+p.GetAge());
            System.Console.WriteLine("Edad: " + p.GetFullName());
            System.Console.ReadKey();
        }
    }
}
