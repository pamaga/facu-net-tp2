﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MisClases
{
    public class Persona
    {

        private int dni;
        private string nombre;
        private string apellido;
        private DateTime edad;

        public Persona(string Nom, string Ape, string fecNacimiento)
        {
            nombre = Nom;
            apellido = Ape;
            String[] _fec = fecNacimiento.Split('/');
            edad = new DateTime(Convert.ToInt32(_fec[2]), Convert.ToInt32(_fec[1]), Convert.ToInt32(_fec[0]));
           
            System.Console.WriteLine("Se ha instanciado el objeto Persona");

        }
        
        ~Persona()
        {
            System.Console.WriteLine("Se ha destruido el objeto persona");
        }

        public string Nombre
        {
            get
            {
                return nombre;
            }
            set
            {
                nombre = value;
            }
        }

        public string Apellido
        {
            get
            {
                return apellido;
            }
            set
            {
            }
        }

        public int GetAge(){
            return DateTime.Today.AddTicks(-edad.Ticks).Year - 1;
        }
       
        public DateTime Edad
        {
             get
            {

                return edad;
                
            }
            set
            {
                edad = value;
            }
        }

        public int Dni
        {
            get
            {
                return dni;
            }
            set
            {
                dni = value;
            }
        }

        public string GetFullName() {
            return nombre + " " + apellido;
        }
    }
}
