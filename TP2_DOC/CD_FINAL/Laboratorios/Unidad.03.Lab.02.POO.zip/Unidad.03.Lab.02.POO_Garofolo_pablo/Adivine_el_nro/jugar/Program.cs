﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Adivine_el_nro;

namespace jugar
{
    class Program
    {
        static void Main(string[] args)
        {
            Juego j = new Juego();
            j.ComenzarJuego();
                        
        }
    }
}
