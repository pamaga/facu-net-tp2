﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Adivine_el_nro
{
    public class JugadaConAyuda : Jugada
    {
        public override void Comparar(int nro){
            if (nro > Numero && nro-100 > Numero) {
                System.Console.WriteLine("El número ingresado es mucho mayor.");
            }
        //Comparar numeros y ayudar al usuario
        }
    }
}
