﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Adivine_el_nro
{
    public class Juego
    {
        private int _record;

        public Juego()
        {
            throw new System.NotImplementedException();
        }

        public void ComenzarJuego()
        {
            throw new System.NotImplementedException();
        }

        public void CompararRecord()
        {
            throw new System.NotImplementedException();
        }

        public void PreguntarMaximo()
        {
            throw new System.NotImplementedException();
        }

        public void PreguntarNumero()
        {
            throw new System.NotImplementedException();
        }
    }
}
